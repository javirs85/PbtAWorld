﻿CREATE TABLE [dbo].[User]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [FirstName] NCHAR(80) NOT NULL, 
    [LastName] NCHAR(50) NOT NULL
)
